	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/popup.js"></script>
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/functions.js"></script>
	<?php include "functions.php"; ?>
