setTimeout(function () {
    var popupMessage = document.getElementById("popupMessage");
    if (popupMessage) {
        popupMessage.style.display = "none";
    }
}, 4000);